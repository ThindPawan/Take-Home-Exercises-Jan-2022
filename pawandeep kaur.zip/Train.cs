﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainSystem
{
    public class Train
    {
        public int RailWeight { get; private set; }
        public Engine Engine { get ; private set; }
        public int TrainGrossWeight
        {
            get
            {
                return Engine.Weight + RailWeight;
            }
           
               
           
         }
        public int MaxGrossWeight
        { get
            { return Engine.Horsepower; }
        }
        public int TotalCars {
            get
            {
                return RailCars.Count();
            } 
        }
        public List<RailCar> RailCars { get; private set; } = null!;

        public void Add(RailCar car) 
        {
            if (TrainGrossWeight <= MaxGrossWeight)

            {
                foreach (RailCar r in RailCars)
                {
                    if (r.GrossWeight <= 0)
                    {
                        RailWeight = r.LightWeight;
                    }
                    else

                    {
                        RailWeight = r.GrossWeight + r.LightWeight;

                    }

                }
                RailCars.Add(car);
            }
            else
            {
                throw new ArgumentOutOfRangeException("The Train Gross Weight do not allow to exceed the maximum gross weight allowed for train.");
            }

        }
       Train(Engine givenEngine) 
       {
           Engine = givenEngine;
       }

        
    }
}
