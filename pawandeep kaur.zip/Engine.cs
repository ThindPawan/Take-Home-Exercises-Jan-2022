﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainSystem
{
    public class Engine
    {
        private string _model = null!;
        private string _serialnumber = null!;
        private int _weight;
        private int _horsepower;

       
        public string Model
        {
            get { return _model; }
            private set
            {
                if (value.Trim().Length <= 0)
                {
                    throw new ArgumentNullException("Model", "Model is not specified or is empty.");
                }
               
                _model = value.Trim();
            }
        }
       
        
        public string SerialNumber
        {
            get { return _serialnumber; }
            private set
            {
                if (value.Trim().Length <= 0)
                {
                    throw new ArgumentNullException("SerialNumber", "SerialNumber is not specified or is empty.");
                }
               
                _serialnumber = value.Trim();
            }
        }
        public int Weight
        {
            get { return _weight; }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentNullException("weight", "weight must be a postive wholenumber.");
                }
                if (value % 100 != 0)
                {
                    throw new ArgumentOutOfRangeException("weight", value, "weight must be in increments of 100.");
                }
                _weight = value;

            }
        }
        public int Horsepower
        {
            get { return _horsepower; }
            private set
            {

                if (value >= 5500 && value <= 3500 || value == 0)
                {
                    throw new ArgumentOutOfRangeException("Horsepower", value, "Horse Power must be a positive whole number between 3500 and 5500");
                }
                if(value % 100 != 0)
                {
                    throw new ArgumentOutOfRangeException("Horsepower", value, "Horsepower must be in increments of 100");
                }
                _horsepower = value;
            }
        }
        public Engine(string model, string serialnumber, int weight, int horsepower)
        {
            Model = model;
            SerialNumber = serialnumber;
            Weight = weight;
            Horsepower = horsepower;
        }
        public override string ToString()
        {
            return $"{Model} model, {SerialNumber} serialnumber, {Weight} pounds, {Horsepower} hp";
        }
    }
}
