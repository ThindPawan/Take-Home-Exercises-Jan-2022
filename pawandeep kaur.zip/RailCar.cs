﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainSystem
{
    public class RailCar
    {
        //Enum//
        public enum RailCarType
        {
            Box_car,
            Coal_car,
            Covered_hopper
        }
        //Fields//
        private int _capacity;
        private int _lightWeight;
        private int _loadLimit;
        private string _serialNumber = null!;

        //Properties//


        public RailCarType Type;


        public string SerialNumber
        {
            get { return _serialNumber; }
            set
            {
                if (value.Trim().Length <= 0)
                {
                    throw new ArgumentNullException("SerialNumber", "SerialNumber is not specified or is empty.");
                }
                _serialNumber = value.Trim();
            }
        }

        public int LightWeight
        {
            get { return _lightWeight; }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException("Capacity", value, "Capacity must be always be positive or non-zero whole number");
                }
                if (value % 100 != 0)
                {
                    throw new ArgumentOutOfRangeException("Capacity", value, "Capacity must be in increment of 100");
                }
                _lightWeight = value;
            }
        }

       
        public int Capacity
        {
            get { return _capacity; }
            private set
            {
                if (value <= 0 )
                {
                    throw new ArgumentOutOfRangeException("Capacity", value, "Capacity must be always be positive or non-zero whole number");
                }
                if(value % 100 != 0)
                {
                    throw new ArgumentOutOfRangeException("Capacity", value, "Capacity must be in increment of 100");
                }
                if(value >= LoadLimit)
                {
                    throw new ArgumentOutOfRangeException("Capacity", value, "Capacity must be less than loadlimit");
                }
                _capacity = value;
            }
        }
        public int GrossWeight
        {
         get;
         private set;
        }

        public bool Inservice
        { get; private set; }

        public bool IsFull 
        {
            get { return LoadLimit == (Capacity * 0.9); }
        }
        

        public int LoadLimit
        {
            get { return _loadLimit; }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException("LoadLimit", value, "LoadLimit must be always be positive or non-zero whole number");
                }
                if (value % 100 != 0)
                {
                    throw new ArgumentOutOfRangeException("LoadLimit", value, "LoadLimit must be in increment of 100");
                }
                _loadLimit = value;
            }

        }
        

        public int NetWeight
        { 
            get { return GrossWeight - LightWeight; } 
        }

        

        //method//
       


        public RailCar(string serialNumber, int lightweight, int capacity, int loadLimit, RailCarType type, bool inservice)
        {
            SerialNumber = serialNumber;
            LightWeight = lightweight;
            Capacity = capacity;
            LoadLimit = loadLimit;
            Type = type;
            Inservice = inservice;
            GrossWeight = lightweight;
        }
        public void RecordScaleWeight(int grossweight)
        {
            if(GrossWeight <= LightWeight )
            {
                throw new ArgumentOutOfRangeException("GrossWeight", grossweight, "Scale Error- Grossweight must be grater than LightWeight.");
            }
            if(GrossWeight > ( LoadLimit + LightWeight))
           
            {
                throw new ArgumentOutOfRangeException("GrossWeight", grossweight, "Unsafe Error- Grossweight must be less than load limit.");
            }
            GrossWeight = grossweight;
        }
        public override string ToString()
        {
            return $"{SerialNumber} SerialNumber, {LightWeight} LightWeight, {Capacity} Capacity, {LoadLimit} LoadLimit, {Type} Type, {Inservice} InService, {IsFull} Isfull, {NetWeight} NetWeight, {GrossWeight} Grossweight";
        }
        

    }

   
}
