﻿using TrainSystem;
using System.Collections.Generic;

Console.WriteLine("Testing Engine");
TestEngine();
static void TestEngine()
{
    try
    {
        Engine newEngine;
        //Good Engine
        newEngine = new Engine("CP 8002", "48807", 147700, 4400);

        // Bad Engine

        //Model = zero
        // newEngine = new Engine("", "48807", 147700, 4400);

        //Weight = negative
        // newEngine = new Engine("CP 8002", "48807", -147700, 4400);
        //Weight = not 100 increment
        //newEngine = new Engine("CP 8002 ", "48807", 14777, 4400);

        //Horsepower = not between 3500 & 5500
        // newEngine = new Engine("CP 8002", "48807", 147700, 9000);
        //Horsepower = not in 100 increment
        //newEngine = new Engine("CP 8002", "48807", 147700, 4412);



    }
    catch (ArgumentNullException  ep)
    {
        Console.WriteLine(ep.Message);
    }
    catch( ArgumentOutOfRangeException ee)
    {
       Console.WriteLine(ee.Message);
    }

    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }
    
    Console.WriteLine("Testing RailCar");
    TestRailCar();
    static void TestRailCar()
    {
        try
        {
            RailCar railcar;
            // Good railcar
            railcar = new RailCar("18172", 5000, 7500, 5500, RailCar.RailCarType.Box_car, true);

            railcar.RecordScaleWeight(4300);
            Console.WriteLine(railcar.GrossWeight);

            //bad railcar
            //serial number = empty
            // railcar = new RailCar("", 5000, 7500, 5500, RailCar.RailCarType.Box_car, true);

            //lightweight = null or zero
            //railcar = new RailCar("18172",0, 7500, 5500, RailCar.RailCarType.Box_car, true);
            //lightweight = not in 100 increment
            // railcar = new RailCar("18172",4599, 7500, 5500, RailCar.RailCarType.Box_car, true);

            //capacity = null or zero
            //railcar = new RailCar("18172", 5000, 0, 5500, RailCar.RailCarType.Box_car, true);

            //capacity = not in 100 increment
            //railcar = new RailCar("18172", 5000, 7499, 5500, RailCar.RailCarType.Box_car, true);

            //load limit = null or zero
            //railcar = new RailCar("18172", 5000, 7500, 0, RailCar.RailCarType.Box_car, true);

            // bad loadlimit - when capacity is not in 100 increment
            //railcar = new RailCar("18172", 5000, 7500, 7499, RailCar.RailCarType.Box_car, true);
            bool IsFull = GetIsFull(5500, 7500);
            static bool GetIsFull (int loadlimit, int capacity)
            {
                bool isfull = false;
                if(loadlimit == (capacity * 0.0))
                {
                    isfull = true;
                }
                return isfull;
            }            
              Console.WriteLine();
              Console.WriteLine("test done");
           
            // railcar.RecordScaleWeight(3500);






        }
        catch (ArgumentNullException ep)
        {
            Console.WriteLine(ep.Message);
        }
        catch (ArgumentOutOfRangeException ee)
        {
            Console.WriteLine(ee.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }


    }
    
}